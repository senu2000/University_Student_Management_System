package com.example.university_student_management_system;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class DisplayUserName {

//    @FXML
//    private static Label lbl_WelcomeName;

    public static String username;


}
